<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Grupousuario;
use Faker\Generator as Faker;

$factory->define(Grupousuario::class, function (Faker $faker) {
    return [
        //
    ];
});
