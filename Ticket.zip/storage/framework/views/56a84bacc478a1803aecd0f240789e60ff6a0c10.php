<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php if(session()->has('MOD_USUARIOS')): ?>
            <div class="col-lg-4 col-md-6 col-sm-6">
                <a href="<?php echo e(route('admin.usuarios')); ?>">
                    <div class="card card-stats">
                        <div class="card-header card-header-success card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">supervised_user_circle</i>
                            </div>
                            <p class="card-category">Modulo</p>
                            <h3 class="card-title">Usuario</h3>
                        </div>
                        <div class="card-footer">
                        </div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if(session()->has('MOD_GENERAL')): ?>
            <div class="col-lg-4 col-md-6 col-sm-6">
                <a href="<?php echo e(route('admin.general')); ?>">
                    <div class="card card-stats">
                        <div class="card-header card-header-rose card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">account_balance</i>
                            </div>
                            <p class="card-category">Modulo</p>
                            <h3 class="card-title">General</h3>
                        </div>
                        <div class="card-footer">
                        </div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
           <?php if(session()->has('MOD_MANTENIMIENTO')): ?>
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <a href="<?php echo e(route('admin.usuarios')); ?>">
                        <div class="card card-stats">
                            <div class="card-header card-header-success card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">build</i>
                                </div>
                                <p class="card-category">Modulo</p>
                                <h3 class="card-title">Mantenimiento</h3>
                            </div>
                            <div class="card-footer">
                            </div>
                        </div>
                    </a>
                </div>
           <?php endif; ?>

            <?php if(session()->has('MOD_REPORTE')): ?>
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <a href="<?php echo e(route('admin.reporte')); ?>">
                        <div class="card card-stats">
                            <div class="card-header card-header-success card-header-icon" >
                                <div class="card-icon">
                                    <i class="material-icons">trending_up</i>
                                </div>
                                <p class="card-category">Modulo</p>
                                <h3 class="card-title">Reportes</h3>
                            </div>
                            <div class="card-footer">
                            </div>
                        </div>
                    </a>
                </div>
            <?php endif; ?>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-danger card-header-icon">
                            <div class="card-icon">
                                <a href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                                   style="color: white"><i class="material-icons">toggle_off</i></a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </div>
                            <p class="card-category">Cerrar</p>
                            <h3 class="card-title">Sesión</h3>
                        </div>
                        <div class="card-footer">
                        </div>
                    </div>
                </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyectos\Ticket\resources\views/home.blade.php ENDPATH**/ ?>