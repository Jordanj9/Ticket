<?php $__env->startSection('breadcrumb'); ?>
    <div class="panel box-shadow-none content-header">
        <div class="panel-body">
            <div class="col-md-12">
                <p class="animated fadeInDown">
                    <a href="<?php echo e(route('inicio')); ?>">Inicio </a><span class="fa-angle-right fa"></span><a
                        href="<?php echo e(route('admin.usuarios')); ?>"> Módulo Usuarios </a><span class="fa-angle-right fa"></span>
                    Listar Usuarios
                </p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row clearfix">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-success card-header-text">
                    <div class="card-text col-md-6">
                        <h4 class="card-title">USUARIOS - LISTADO DE USUARIOS DEL SISTEMA</h4>
                    </div>
                    <div class="pull-right col-md-6">
                        <ul class="navbar-nav pull-right">
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="#" id="navbarDropdownProfile" data-toggle="dropdown"
                                   aria-haspopup="true" aria-expanded="false">
                                    <i class="material-icons">more_vert</i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                                    <a href="<?php echo e(route('usuario.create')); ?>" class="dropdown-item" href="#">Agregar nuevo
                                        usuario</a>
                                    <a class="dropdown-item" href="#" data-toggle="modal"
                                       data-target="#mdModal">Ayuda</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="datatables" class="table table-bordered table-striped table-hover table-responsive table-condensed dataTable js-exportable" width="100%" cellspacing="0"
                               width="100%" style="width:100%">
                            <thead>
                            <tr>
                                <th>IDENTIFICACIÓN</th>
                                <th>USUARIO</th>
                                <th>E-MAIL</th>
                                <th>ESTADO</th>
                                <th>ROLES</th>
                                <th>CREADO</th>
                                <th>MODIFICADO</th>
                                <th>ACCIONES</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($usuario->identificacion); ?></td>
                                    <td><?php echo e($usuario->nombres); ?> <?php echo e($usuario->apellidos); ?></td>
                                    <td><?php echo e($usuario->email); ?></td>
                                    <td><?php if($usuario->estado=='ACTIVO'): ?><label
                                            class="label label-success">ACTIVO</label><?php else: ?><label
                                            class="label label-danger">INACTIVO</label><?php endif; ?></td>
                                    <td>
                                        <?php $__currentLoopData = $usuario->grupousuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($grupo->nombre); ?> -
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($usuario->created_at); ?></td>
                                    <td><?php echo e($usuario->updated_at); ?></td>
                                    <td style="text-align: center;">
                                        <form class="form-horizontal form-label-left" method="POST"
                                              action="<?php echo e(route('usuario.operaciones')); ?>"><input type="hidden" name="id" value="<?php echo e($usuario->identificacion); ?>"/>
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-link btn-info btn-just-icon" type="submit"
                                                    data-toggle="tooltip" data-placement="top" title="Editar Usuario"><i
                                                    class="material-icons">mode_edit</i></button>
                                        </form>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th>IDENTIFICACIÓN</th>
                                <th>USUARIO</th>
                                <th>E-MAIL</th>
                                <th>ESTADO</th>
                                <th>ROLES</th>
                                <th>CREADO</th>
                                <th>MODIFICADO</th>
                                <th class="text-right">ACCIONES</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade modal-mini modal-primary" id="mdModal" tabindex="-1" role="dialog"
         aria-labelledby="myModalLabel" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-small">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i
                            class="material-icons">clear</i></button>
                </div>
                <div class="modal-body">
                    <strong>Detalles: </strong>Gestione los usuarios del sistema con sus diferentes roles.
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">ACEPTAR</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#datatables').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/nikorrie/pctools/resources/views/usuarios/usuarios/list.blade.php ENDPATH**/ ?>