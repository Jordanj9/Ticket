<?php $__env->startSection('breadcrumb'); ?>
    <div class="panel box-shadow-none content-header">
        <div class="panel-body">
            <div class="col-md-12">
                <p class="animated fadeInDown">
                    <a href="<?php echo e(route('inicio')); ?>">Inicio </a><span class="fa-angle-right fa"></span><a
                        href="<?php echo e(route('admin.general')); ?>"> General </a><span
                        class="fa-angle-right fa"></span><a href="<?php echo e(route('equipos.index')); ?>"> Equipos</a><span
                        class="fa-angle-right fa"></span> Crear
                </p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row clearfix">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-success card-header-text">
                    <div class="card-text col-md-6">
                        <h4 class="card-title">DATOS DEL EQUIPO</h4>
                    </div>
                    <div class="pull-right col-md-6">
                        <ul class="navbar-nav pull-right">
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="#" id="navbarDropdownProfile" data-toggle="dropdown"
                                   aria-haspopup="true" aria-expanded="false">
                                    <i class="material-icons">more_vert</i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                                    <a class="dropdown-item" href="#" data-toggle="modal"
                                       data-target="#mdModal">Ayuda</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="card-body">
                    <div class="col-md-12">
                        <?php $__env->startComponent('layouts.errors'); ?>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                    <div class="col-md-12">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('equipos.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-8">
                                </div>
                                <div class="col-md-4">
                                    <a data-toggle="modal" data-target="#clientes"
                                       class="btn bg-info waves-effect btn-block">CONSULTAR PROPIETARIO DEL EQUIPO
                                    </a>
                                </div>
                            </div>
                            <div class="row" id="datos_cliente" style="display: none;">
                                <div class="col-md-4">
                                    <input type="hidden" name="cliente_id" id="cliente_id" required>
                                    <input type="hidden" name="tipo" id="tipo" required>
                                    <div class="form-group bmd-form-group">
                                        <div class="form-line">
                                            <label class="control-label">Identificaciòn</label>
                                            <input type="text" class="form-control"
                                                   required="required" id="identificacion_cliente" disabled placeholder=""
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="form-group bmd-form-group">
                                        <div class="form-line">
                                            <label class="control-label">Nombres</label>
                                            <input type="text" class="form-control"
                                                   required="required" id="nombre_cliente" disabled placeholder=""
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <h4>Descripción del Equipo</h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group bmd-form-group">
                                        <div class="form-line">
                                            <label class="control-label">Año de Aquisiciòn</label>
                                            <input type="number" min="1998" max="2019" class="form-control" name="anio_adquicision"
                                                   required="required" placeholder="Año en el cual el cliente adquirio el equipo"
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group bmd-form-group">
                                        <div class="form-line">
                                            <label class="control-label">Pantalla</label>
                                            <input type="text" class="form-control" name="pantalla"
                                                   required="required" placeholder="Detalle de la pantalla"
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group bmd-form-group">
                                        <div class="form-line">
                                            <label class="control-label">Marca</label>
                                            <input type="text" class="form-control" name="marca"
                                                   required="required" placeholder="marca del equipo"
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group bmd-form-group">
                                        <div class="form-line">
                                            <label class="control-label">Procesador</label>
                                            <input type="text" class="form-control"
                                                   required="required" name="procesador" placeholder="Detalle del procesador"
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group bmd-form-group">
                                        <div class="form-line">
                                            <label class="control-label">Memoria Ram</label>
                                            <input type="text" class="form-control"
                                                   required="required" name="memoria_ram"
                                                   placeholder="Detalle de la memoria ram"
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group bmd-form-group">
                                        <div class="form-line">
                                            <label class="control-label">Disco Duro</label>
                                            <input type="text" class="form-control"
                                                   required="required" name="disco_duro"
                                                   placeholder="Detalle del disco duro"
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="form-group bmd-form-group">
                                        <div class="form-line">
                                            <label class="control-label">Licencias</label>
                                            <textarea id="licencias"
                                                      class="form-control" id="" cols="30" rows="10" name ="licencias"
                                                      placeholder="licencias con las que cuenta el equipo"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                </div>
                                <div class="col-md-4" style="margin-top: -150px;">
                                    <a data-toggle="modal" data-target="#licencia"
                                       class="btn bg-defaut waves-effect btn-round"><i class="material-icons">
                                            fingerprint
                                        </i> Agregar licencia
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6 offset-3">
                                <div class="form-group">
                                    <br/><br/><a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-danger btn-round">Cancelar</a>
                                    <button class="btn btn-info btn-round" type="reset">Limpiar Formulario</button>
                                    <button class="btn btn-success btn-round" type="submit" onclick="guardar(event)">Guardar</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade modal-mini modal-primary" id="mdModal" tabindex="-1" role="dialog"
         aria-labelledby="myModalLabel" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-small">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i
                            class="material-icons">clear</i></button>
                </div>
                <div class="modal-body">
                    <strong>Agregue nuevos Equipos,</strong> el nombre del módulo no debe llevar acentos, eñes (ñ) ni
                    caracteres especiales, el nombre del módulo debe iniciar con "MOD_" seguido del nombre que usted
                    desee. Los módulos generales del sistema son las aplicaciones generales representadas en las
                    opciones del menú. Ejemplo de modulo general: MOD_INICIO, MOD_USUARIO, ETC.
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">ACEPTAR</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="clientes" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Clientes Registrados</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                        <i class="material-icons">clear</i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="material-datatables">
                        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0"
                               width="100%" style="width:100%">
                            <thead>
                            <tr>
                                <th>IDENTIFICACION</th>
                                <th>NOMBRES</th>
                                <th>TIPO PERSONA</th>
                                <th class="text-right">ACCIONES</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($cliente['identificacion']); ?></td>
                                    <td><?php echo e($cliente['nombre']); ?></td>
                                    <td><?php echo e($cliente['tipo']); ?></td>
                                    <td style="text-align: center;">
                                        <a href=""
                                           onclick="selecionarCliente(event,'<?php echo e($cliente['identificacion']); ?>','<?php echo e($cliente['nombre']); ?>','<?php echo e($cliente['id']); ?>','<?php echo e($cliente['tipo']); ?>')"
                                           class="btn btn-link btn-info btn-just-icon remove" title="Editar Equipo"><i
                                                class="material-icons">
                                                arrow_forward_ios
                                            </i></a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th>IDENTIFICACION</th>
                                <th>NOMBRES</th>
                                <th>TIPO PERSONA</th>
                                <th class="text-right">ACCIONES</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger btn-link" data-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="licencia" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Detalle</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group bmd-form-group">
                                <div class="form-line">
                                    <label class="control-label">Programa</label>
                                    <input type="text" class="form-control"
                                           required="required" id="programa_id"
                                           placeholder="programa al que pertenece la licencia"
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group bmd-form-group">
                                <div class="form-line">
                                    <label class="control-label">Descripción</label>
                                    <textarea name="" class="form-control" id="detalle" cols="30" rows="10"
                                              placeholder="Detalle de la licencia"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" onclick="agregarLicecncia()" class="btn btn-success btn-link"
                            data-dismiss="modal"><i class="material-icons">
                            note_add
                        </i>Agregar
                    </button>
                    <button type="button" class="btn btn-danger btn-link" data-dismiss="modal"><i
                            class="material-icons">
                            cancel
                        </i>Cancelar
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            var table = $('#datatables').DataTable();
        });
        
        function selecionarCliente(event, identificacion, nombres,id,tipo) {
            event.preventDefault();
            $('#clientes').modal('hide');
            $('#identificacion_cliente').val(identificacion);
            $('#nombre_cliente').val(nombres);
            $('#cliente_id').val(id);
            $('#tipo').val(tipo);
            $('#datos_cliente').attr('style', 'display:flex;');
        }

        function agregarLicecncia() {
            $('#licencia').modal('hide');
            const programa = $("#programa_id").val();
            const detalle = $("#detalle").val();
            const licencia =$("#licencias").val() + programa + "\n" + detalle + "\n";
            $("#licencias").val(licencia);
            $("#programa_id").val("");
            $("#detalle").val("");
        }

        function guardar(event){
          
            const clientehasValue = $('#cliente_id').val().length > 0;
            $('#licencias').removeAttr('disabled');
            if(!clientehasValue){
              event.preventDefault();
                $.notify({
                    icon: "add_alert",
                    message: 'Debe selecionar el cliente al cual pertenece el equipo a registrar.'
                }, {type: 'danger', timer: 3e3, placement: {from: 'top', align: 'right'}});
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/packporn/pctools/resources/views/general/equipos/create.blade.php ENDPATH**/ ?>