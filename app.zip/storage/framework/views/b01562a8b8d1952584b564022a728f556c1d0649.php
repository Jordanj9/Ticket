<?php $__env->startSection('breadcrumb'); ?>
    <div class="panel box-shadow-none content-header">
        <div class="panel-body">
            <div class="col-md-12">
                <p class="animated fadeInDown">
                    <a href="<?php echo e(route('inicio')); ?>">Inicio</a> <span class="fa-angle-right fa"></span> Módulo Reporte
                </p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row clearfix">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-success card-header-text">
                    <div class="card-text">
                        <h4 class="card-title">REPORTE</h4>
                    </div>
                </div>
                <div class="card-body">
                 <?php if(session()->has('PAG_REPORTEGENERAL')): ?>
                    <a href="<?php echo e(route('reporte.index')); ?>">
                        <button class="btn btn-outline-info btn-round">
                            <i class="fa fa-cubes"></i> REPORTE GENERAL
                            <div class="ripple-container"></div>
                        </button>
                    </a>
                 <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/nikorrie/pctools/resources/views/menu/reporte.blade.php ENDPATH**/ ?>